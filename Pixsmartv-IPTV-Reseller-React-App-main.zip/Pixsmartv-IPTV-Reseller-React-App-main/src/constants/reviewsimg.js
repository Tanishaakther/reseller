import testi1 from '../assets/Reviews/testi1.webp';
import testi2 from '../assets/Reviews/testi2.webp';
import testi3 from '../assets/Reviews/testi3.webp';
import testi4 from '../assets/Reviews/testi4.webp';
import testi5 from '../assets/Reviews/testi5.webp';
import testi6 from '../assets/Reviews/testi6.webp';
import testi7 from '../assets/Reviews/testi7.webp';
import testi8 from '../assets/Reviews/testi8.webp';

export default {
  testi1,
  testi2,
  testi3,
  testi4,
  testi5,
  testi6,
  testi7,
  testi8
};