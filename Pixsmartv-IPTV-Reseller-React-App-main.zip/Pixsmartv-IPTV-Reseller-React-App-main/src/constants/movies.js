import barbie from '../assets/Movies/barbie.webp';
import creed from '../assets/Movies/creed.webp';
import jhonWick4 from '../assets/Movies/jhon-wick-4.webp';
import magicMikes from '../assets/Movies/magic-mikes.webp';
import megan from '../assets/Movies/megan.webp';
import oppenheimer from '../assets/Movies/oppenheimer.webp';
import quantumania from '../assets/Movies/quantumania.webp';
import scream6 from '../assets/Movies/Scream-6.webp';
import spiderMan from '../assets/Movies/spider-man.webp';
import aManCalledOtto from '../assets/Movies/a-man-called-otto.webp';

export default {
  barbie,
  creed,
  jhonWick4,
  magicMikes,
  megan,
  oppenheimer,
  quantumania,
  scream6,
  spiderMan,
  aManCalledOtto
};